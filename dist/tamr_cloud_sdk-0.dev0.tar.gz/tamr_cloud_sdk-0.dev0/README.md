# Python SDK for Tamr Cloud

DISCLAIMER: This is an in development tool that is pre-release. This tool will not work outside of the Tamr network. 